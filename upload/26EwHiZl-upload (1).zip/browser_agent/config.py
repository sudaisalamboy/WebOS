"""Central configuration — no magic numbers inline in modules."""

from pathlib import Path

# --- visual change gate -------------------------------------------------
PHASH_HAMMING_THRESHOLD = 8      # bits differing (of 64) => page "changed"
DIFF_CROP_PADDING = 40           # px around the changed bounding box
MIN_CHANGED_PIXELS = 600         # measured: focus ring ~336px, text change ~984px

# --- page settle --------------------------------------------------------
SETTLE_DELAY_MS = 800            # wait after action before observing
NAV_TIMEOUT_MS = 45000

# --- agent loop ---------------------------------------------------------
MAX_STEPS = 25
STEP_TIMEOUT_S = 120

# --- storage ------------------------------------------------------------
CACHE_DIR = Path(".browser_agent_cache")
SCREENSHOT_DIR = CACHE_DIR / "shots"

# --- connection ---------------------------------------------------------
CDP_URL = "http://localhost:9222"

# --- LLM (any OpenAI-compatible endpoint) --------------------------------
LLM_BASE_URL = "http://api.openai.com/v1"   # override for local/other providers
LLM_MODEL = "gpt-4o-mini"
LLM_API_KEY = ""                              # or set OPENAI_API_KEY env var
