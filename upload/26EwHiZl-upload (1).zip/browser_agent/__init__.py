"""browser_agent — screenshot-efficient AI browser control."""
