"""Browser connection + actions. Attaches to your real Chrome via CDP."""

from playwright.sync_api import sync_playwright, Browser, Page, Playwright

CDP_URL = "http://localhost:9222"


class BrowserController:
    def __init__(self, cdp_url: str = CDP_URL, headless: bool = False, use_cdp: bool = True):
        self.cdp_url = cdp_url
        self.headless = headless
        self.use_cdp = use_cdp
        self._pw: Playwright | None = None
        self.browser: Browser | None = None
        self.page: Page | None = None

    def start(self) -> "BrowserController":
        self._pw = sync_playwright().start()
        if self.use_cdp:
            try:
                self.browser = self._pw.chromium.connect_over_cdp(self.cdp_url)
                # Reuse the profile's first tab if present, else open one
                ctx = self.browser.contexts[0] if self.browser.contexts else self.browser.new_context()
                self.page = ctx.pages[0] if ctx.pages else ctx.new_page()
                return self
            except Exception:
                pass  # fall through to managed launch
        # Managed fallback: launch Chromium with automation flags hidden
        self.browser = self._pw.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
            ],
        )
        ctx = self.browser.new_context()
        # hide navigator.webdriver (basic stealth)
        ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined})"
        )
        self.page = ctx.new_page()
        return self

    def stop(self):
        if self.browser:
            self.browser.close()
        if self._pw:
            self._pw.stop()

    # ---- actions -------------------------------------------------------

    def goto(self, url: str):
        if "://" not in url:
            url = "https://" + url
        self.page.goto(url, wait_until="domcontentloaded", timeout=45000)
        self.page.wait_for_timeout(800)  # let JS render settle

    def click(self, ref: int):
        el = self.page.locator(f"[data-ai-ref='{ref}']").first
        el.scroll_into_view_if_needed()
        el.click(timeout=8000)

    def type_text(self, ref: int, text: str):
        el = self.page.locator(f"[data-ai-ref='{ref}']").first
        el.scroll_into_view_if_needed()
        el.fill(text)

    def press(self, key: str):
        self.page.keyboard.press(key)

    def scroll(self, direction: str = "down", amount: int = 600):
        dy = amount if direction == "down" else -amount
        self.page.mouse.wheel(0, dy)
        self.page.wait_for_timeout(400)

    def screenshot(self, full_page: bool = False) -> bytes:
        return self.page.screenshot(full_page=full_page, type="png")

    def screenshot_element(self, ref: int) -> bytes:
        el = self.page.locator(f"[data-ai-ref='{ref}']").first
        return el.screenshot(type="png")

    def tabs(self):
        out = []
        for i, pg in enumerate(self.page.context.pages):
            out.append(f"[{i}] {pg.title()} - {pg.url}")
        return "\n".join(out)

    def switch_tab(self, idx: int):
        self.page = self.page.context.pages[idx]
