"""Allow `python -m browser_agent` as a shorthand for the CLI."""

import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
