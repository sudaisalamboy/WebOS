"""Agent loop: act → observe → decide, with the change gate in the middle."""

from __future__ import annotations

import os
import re
import time
from dataclasses import dataclass

from . import config
from .browser import BrowserController
from .dom_state import DomState
from .vision import VisionGate, VisualObservation

SYSTEM_PROMPT = """You control a browser via text state and, only when the page
visually changed, a cropped screenshot of the changed region.

Reply with ONE action per turn, plain text:
  open <url>
  click <ref>
  type <ref> <text>
  press <key>            (e.g. press Enter)
  scroll down|up
  shot                   (force a full screenshot)
  done <summary>

Refs like [12] come from the ELEMENTS list. Prefer text state; the image shows
only what changed since the last step."""


@dataclass
class Observation:
    step: int
    action: str
    text_state: str
    image_path: str | None
    note: str


class LLMClient:
    """Minimal OpenAI-compatible chat client. Swap by subclassing."""

    def __init__(self):
        from openai import OpenAI  # lazy: only needed for autonomous mode
        self.client = OpenAI(
            base_url=config.LLM_BASE_URL,
            api_key=config.LLM_API_KEY or os.environ.get("OPENAI_API_KEY", ""),
        )

    def decide(self, messages: list) -> str:
        resp = self.client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=messages,
            max_tokens=300,
        )
        return resp.choices[0].message.content.strip()


class Agent:
    def __init__(self, ctrl: BrowserController, llm: LLMClient | None = None):
        self.ctrl = ctrl
        self.llm = llm
        self.state = DomState(ctrl.page)
        self.gate = VisionGate()
        self.history: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.observations: list[Observation] = []

    # -- observation -----------------------------------------------------

    def observe(self, action: str, force_shot: bool = False) -> Observation:
        self.ctrl.page.wait_for_timeout(config.SETTLE_DELAY_MS)
        text_state = self.state.capture()
        png = self.ctrl.screenshot(full_page=False)
        if force_shot:
            vis = VisualObservation(True, self.gate.force_full(png), 0, 0,
                                    "forced full screenshot")
        else:
            vis = self.gate.observe(png)
        obs = Observation(
            step=len(self.observations) + 1,
            action=action,
            text_state=text_state,
            image_path=vis.image_path,
            note=f"[{vis.reason} | hamming={vis.hamming} | px={vis.changed_pixels}]",
        )
        self.observations.append(obs)
        return obs

    # -- execution -------------------------------------------------------

    def execute(self, action: str):
        m = re.match(r"(open|click|type|press|scroll|shot|done)\b(.*)", action.strip())
        if not m:
            return f"unknown action: {action}"
        cmd, rest = m.group(1), m.group(2).strip()
        page = self.ctrl.page
        try:
            if cmd == "open":
                self.ctrl.goto(rest)
            elif cmd == "click":
                self.ctrl.click(int(rest))
                page.wait_for_timeout(500)
            elif cmd == "type":
                ref, _, text = rest.partition(" ")
                self.ctrl.type_text(int(ref), text)
            elif cmd == "press":
                self.ctrl.press(rest)
            elif cmd == "scroll":
                self.ctrl.scroll(rest or "down")
            elif cmd == "shot":
                return None  # handled by force_shot
            elif cmd == "done":
                return rest or ""
            return None
        except Exception as e:
            return f"error: {e.__class__.__name__}: {e}"

    # -- autonomous loop ---------------------------------------------------

    def run(self, task: str) -> str:
        assert self.llm, "pass an LLMClient for autonomous mode"
        deadline = time.time() + config.STEP_TIMEOUT_S
        self.history.append({"role": "user", "content": task})
        for step in range(config.MAX_STEPS):
            if time.time() > deadline:
                return "stopped: timeout"
            reply = self.llm.decide(self.history)
            self.history.append({"role": "assistant", "content": reply})
            if reply.startswith("done"):
                return reply[4:].strip() or "done"
            err = self.execute(reply)
            obs = self.observe(reply, force_shot=reply.strip() == "shot")
            content = (err + "\n" if err else "") + obs.note + "\n" + obs.text_state
            if obs.image_path:
                content += f"\n[IMAGE: {obs.image_path}]"
            self.history.append({"role": "user", "content": content})
        return "stopped: max steps reached"
