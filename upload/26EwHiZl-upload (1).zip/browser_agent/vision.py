"""Visual observation channel — screenshot only when the page actually changed.

Gate logic (all local & cheap; the expensive part is sending images to a
model, and that only happens on a real change):

  changed = pHash Hamming > threshold OR changed_pixels >= min threshold

The pixel diff is primary because perceptual hashes miss small text changes
(the most common meaningful change for an agent). Sub-threshold diffs do NOT
advance the baseline, so slow cumulative changes eventually fire.
"""

from __future__ import annotations

import io
from dataclasses import dataclass

import cv2
import imagehash
import numpy as np
from PIL import Image

from . import config

GRAY_DIFF_T = 25  # per-pixel intensity delta considered "different"


@dataclass
class VisualObservation:
    changed: bool
    image_path: str | None = None   # crop of changed region (or full shot)
    hamming: int = 0
    changed_pixels: int = 0
    reason: str = "no change"


class VisionGate:
    def __init__(self):
        self.last_hash: imagehash.ImageHash | None = None
        self.last_array: np.ndarray | None = None
        self.shot_no = 0
        self._last_path: str | None = None
        config.SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    # -- helpers ---------------------------------------------------------

    @staticmethod
    def _decode(png_bytes: bytes):
        pil = Image.open(io.BytesIO(png_bytes)).convert("RGB")
        arr = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
        return pil, arr

    @staticmethod
    def _diff_mask(arr: np.ndarray, prev: np.ndarray) -> np.ndarray | None:
        if arr.shape != prev.shape:
            return None
        gray = cv2.cvtColor(cv2.absdiff(arr, prev), cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, GRAY_DIFF_T, 255, cv2.THRESH_BINARY)
        return mask

    # -- core ------------------------------------------------------------

    def observe(self, png_bytes: bytes) -> VisualObservation:
        pil, arr = self._decode(png_bytes)
        h = imagehash.phash(pil)

        if self.last_hash is None:
            self.shot_no += 1
            self._last_path = str(config.SCREENSHOT_DIR / f"full_{self.shot_no}.png")
            with open(self._last_path, "wb") as fh:
                fh.write(png_bytes)
            self.last_hash, self.last_array = h, arr
            return VisualObservation(True, self._last_path, 0, 0, "first capture")

        hamming = h - self.last_hash
        mask = self._diff_mask(arr, self.last_array)
        changed_pixels = int(cv2.countNonZero(mask)) if mask is not None else float("inf")

        # Pixel count is the decision signal; hamming is telemetry only.
        # (pHash alone fires on tiny high-contrast artifacts and misses small
        # text changes — pixels do neither.)
        if changed_pixels < config.MIN_CHANGED_PIXELS:
            return VisualObservation(False, None, hamming, changed_pixels, "no visual change")

        # real change: save crop of changed region, advance baseline
        prev = self.last_array
        self.last_hash, self.last_array = h, arr
        self.shot_no += 1
        path = config.SCREENSHOT_DIR / f"change_{self.shot_no}.png"
        if mask is None:
            cv2.imwrite(str(path), arr)  # viewport size changed: keep full frame
            reason = "viewport resized, full capture"
        else:
            ys, xs = np.where(mask > 0)
            p = config.DIFF_CROP_PADDING
            y1, y2 = max(0, int(ys.min()) - p), min(arr.shape[0], int(ys.max()) + p)
            x1, x2 = max(0, int(xs.min()) - p), min(arr.shape[1], int(xs.max()) + p)
            cv2.imwrite(str(path), arr[y1:y2, x1:x2])
            reason = "changed region"
        return VisualObservation(True, str(path), hamming, changed_pixels, reason)

    def force_full(self, png_bytes: bytes) -> str:
        """Explicitly requested screenshot (bypasses the gate)."""
        self.shot_no += 1
        path = config.SCREENSHOT_DIR / f"full_{self.shot_no}.png"
        with open(path, "wb") as fh:
            fh.write(png_bytes)
        pil, arr = self._decode(png_bytes)
        self.last_hash, self.last_array = imagehash.phash(pil), arr
        self._last_path = str(path)
        return str(path)
