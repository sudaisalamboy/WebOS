"""REPL: drive the browser by hand (or let another AI drive via stdin).

Runs all three ways:
    python -m browser_agent.cli
    python browser_agent/cli.py
    python cli.py            (from inside browser_agent/)
"""

import sys
from pathlib import Path

if __package__:
    from . import config
    from .agent import Agent
    from .browser import BrowserController
else:  # direct script execution: resolve the package absolutely
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from browser_agent import config
    from browser_agent.agent import Agent
    from browser_agent.browser import BrowserController

HELP = """commands:
  open <url>          navigate
  state               print page state (numbered elements)
  click <n>           click element ref n
  type <n> <text>     fill element ref n
  press <key>         e.g. press Enter
  scroll down|up      scroll viewport
  shot                force a screenshot (saved to cache)
  tabs / tab <i>      list / switch tabs
  quit"""


def main():
    ctrl = BrowserController(config.CDP_URL).start()
    agent = Agent(ctrl)
    print(f"connected: {ctrl.page.url}")
    print(HELP)
    while True:
        try:
            line = input("brow> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            continue
        if line in ("quit", "exit"):
            break
        if line == "help":
            print(HELP)
            continue
        if line == "state":
            print(agent.state.capture())
            continue
        if line == "shot":
            obs = agent.observe(line, force_shot=True)
            print(obs.note, "->", obs.image_path)
            continue
        if line == "tabs":
            print(ctrl.tabs())
            continue
        if line.startswith("tab "):
            ctrl.switch_tab(int(line.split()[1]))
            agent.state = type(agent.state)(ctrl.page)
            print("switched to", ctrl.page.url)
            continue
        err = agent.execute(line)
        if err:
            print(err)
        else:
            obs = agent.observe(line)
            print(obs.note)
    ctrl.stop()
    print("bye")


if __name__ == "__main__":
    sys.exit(main())
