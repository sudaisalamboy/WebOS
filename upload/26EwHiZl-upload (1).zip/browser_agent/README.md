# browser_agent — Screenshot-Efficient AI Browser Control

AI controls your browser by **seeing the rendered page**, but screenshots are
sent **only when the page visually changes** — no screenshot spam.

## How it works

Two observation channels:

| Channel | When | Cost |
|---|---|---|
| DOM state (text) | every step | ~2 KB text |
| Screenshot crop | only when perceptual hash says the page changed | 1 small image |

- **Pixel diff is the decision signal** (≥600 changed px = changed; measured:
  focus ring ≈ 336 px, a text change ≈ 984 px). pHash is telemetry only —
  it misses small text changes and false-fires on tiny artifacts.
- On change, the diff's bounding box is cropped with padding and only that
  **crop** is saved/sent — not the full page.
- Sub-threshold diffs (focus rings, anti-aliasing, blinking ad dots) are
  skipped and don't advance the baseline, so slow cumulative changes still
  eventually fire.

## Setup

```bash
cd browser_agent
pip install -r requirements.txt
playwright install chromium
```

To attach to your **real Chrome** (keeps logins/cookies), start it with:

```bash
google-chrome --remote-debugging-port=9222
```

(If not running, the system auto-launches a stealth Chromium.)

## Use

```bash
python -m browser_agent.cli
```

```
brow> open example.com
brow> state          # numbered elements: [12] button "Sign in"
brow> click 12
no visual change | hamming=2 px=0     <- no screenshot sent
brow> type 3 hello
changed region | hamming=31 px=900    -> .browser_agent_cache/shots/change_2.png
```

## Autonomous mode (LLM in the loop)

```python
from browser_agent.browser import BrowserController
from browser_agent.agent import Agent, LLMClient
from browser_agent import config

config.LLM_BASE_URL = "http://localhost:11434/v1"   # any OpenAI-compatible API
config.LLM_MODEL = "your-model"

ctrl = BrowserController(config.CDP_URL).start()
result = Agent(ctrl, LLMClient()).run("search for cheap flights to Delhi")
print(result)
```

The LLM gets text state every step and an image only on real changes, so a
10-step task typically sends 2–3 small images instead of 10 full screenshots.

## DevTools-blocking sites

Falls back automatically: CDP attach → stealth Chromium
(`--disable-blink-features=AutomationControlled`, `navigator.webdriver` hidden).
For fully hardened sites, OS-level capture via `mss` (no browser
instrumentation) is planned as the third rung.

## Tests

```bash
python tests/test_core.py
```

Verifies: no-change dedup, change crop math, noise gate, live ref clicking.
