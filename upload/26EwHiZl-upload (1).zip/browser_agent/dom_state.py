"""DOM state extraction — the cheap, always-on observation channel.

Injects data-ai-ref attributes into the live DOM so later clicks resolve by
number, immune to selector drift.
"""

from playwright.sync_api import Page

INTERACTIVE_JS = """
() => {
  const sels = 'a[href], button, input, select, textarea, [role="button"], [role="link"], [role="tab"], [onclick], summary';
  const els = Array.from(document.querySelectorAll(sels))
    .filter(e => e.offsetParent !== null || e.getClientRects().length > 0);
  els.forEach(e => e.removeAttribute('data-ai-ref'));
  const lines = [];
  els.forEach((e, i) => {
    e.setAttribute('data-ai-ref', String(i));
    const tag = e.tagName.toLowerCase();
    const kind = tag === 'a' ? 'link' : tag;
    let label = (e.getAttribute('aria-label') || e.innerText ||
                 e.getAttribute('placeholder') || e.getAttribute('value') ||
                 e.getAttribute('name') || e.getAttribute('href') || '')
                 .trim().replace(/\\s+/g, ' ').slice(0, 60);
    const extra = tag === 'input' ? ` type=${e.getAttribute('type') || 'text'}` : '';
    lines.push(`[${i}] ${kind}${extra} "${label}"`);
  });
  return lines;
}
"""

VISIBLE_TEXT_JS = """
() => {
  const skip = new Set(['SCRIPT','STYLE','NOSCRIPT','TEMPLATE']);
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT,
    { acceptNode: n =>
        (skip.has(n.parentElement?.tagName || '')) ? NodeFilter.FILTER_REJECT
      : NodeFilter.FILTER_ACCEPT });
  const seen = new Set(); const parts = [];
  while (walker.nextNode()) {
    const t = walker.currentNode.textContent.trim();
    // drop embedded JSON/config blobs pages like GitHub inject
    if (!t || t.length < 3 || t.length > 400 || seen.has(t)) continue;
    if (t.startsWith('{') || t.startsWith('\\"props\\"')) continue;
    seen.add(t); parts.push(t);
  }
  return parts.slice(0, 150).join(' | ').slice(0, 3500);
}
"""

FORM_VALUES_JS = """
() => Array.from(document.querySelectorAll('input[data-ai-ref], textarea[data-ai-ref], select[data-ai-ref]'))
  .filter(e => e.value)
  .map(e => `[${e.getAttribute('data-ai-ref')}] = "${String(e.value).slice(0, 60)}"`)
"""


class DomState:
    def __init__(self, page: Page):
        self.page = page

    def capture(self) -> str:
        """Return compact text state: title/url, elements, text, form values."""
        self.page.wait_for_timeout(200)
        elements = self.page.evaluate(INTERACTIVE_JS)
        text = self.page.evaluate(VISIBLE_TEXT_JS)
        values = self.page.evaluate(FORM_VALUES_JS)
        parts = [
            f"PAGE: {self.page.title()}",
            f"URL: {self.page.url}",
            "ELEMENTS:",
            *elements,
        ]
        if values:
            parts.append("FORM VALUES: " + "; ".join(values))
        parts.append("TEXT: " + text)
        return "\n".join(parts)
