"""E2E: no-change actions send no images; a real change sends exactly one crop."""

import sys, tempfile, os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from browser_agent.browser import BrowserController
from browser_agent.agent import Agent
from browser_agent import config

def gate_shots():
    return list(config.SCREENSHOT_DIR.glob("*.png"))

html = """<html><body style="font-family:sans-serif">
<h1>Shop</h1><p id="status">Ready.</p>
<button onclick="document.getElementById('status').innerText='Order placed!'">Buy now</button>
<input placeholder="search"><a href="#x">Info</a>
</body></html>"""

f = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False)
f.write(html); f.close()

shots_before = 0
ctrl = BrowserController(headless=True, use_cdp=False).start()
agent = Agent(ctrl)
ctrl.goto("file://" + f.name)
try:
    agent.observe("initial")
    shots_after_init = len(gate_shots())
    # 3 no-change actions
    for act in ["scroll down", "scroll up", "press Tab"]:
        err = agent.execute(act)
        obs = agent.observe(act)
        print(act, "| err:", err, "| url:", ctrl.page.url, "|", obs.note)
        assert not obs.image_path, f"{act} unexpectedly sent an image"
    mid = len(gate_shots())
    assert mid == shots_after_init, "screenshot sent during no-change actions"
    # 1 real change
    err = agent.execute("click 0")
    print("click err:", err, "| url:", ctrl.page.url, "| status:",
          ctrl.page.inner_text("#status") if ctrl.page.url.startswith("file:") else "LEFT PAGE")
    obs = agent.observe("click 0")
    assert obs.image_path and obs.note.startswith("[changed region"), obs.note
    end = len(gate_shots())

    assert end == mid + 1, f"expected exactly 1 new shot, got {end - mid}"
    print(f"E2E PASS: {mid - shots_after_init} shots for 3 no-change actions, "
          f"exactly 1 crop for the real change -> {obs.image_path}")
finally:
    ctrl.stop(); os.unlink(f.name)
