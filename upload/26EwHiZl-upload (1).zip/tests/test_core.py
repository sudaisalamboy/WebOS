"""Unit tests: pHash gate, diff-box crop math, ref injection (live page)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from browser_agent import config
from browser_agent.vision import VisionGate

import cv2
import numpy as np
from PIL import Image


def make_png(color=(200, 200, 200), box=None):
    arr = np.full((400, 600, 3), color, dtype=np.uint8)
    if box:  # (x, y, w, h, color)
        x, y, w, h, c = box
        arr[y:y + h, x:x + w] = c
    ok, png = cv2.imencode(".png", arr)
    assert ok
    return png.tobytes()


def test_no_change_skipped():
    g = VisionGate()
    a = g.observe(make_png())
    assert a.changed  # first capture always fires
    b = g.observe(make_png())
    assert not b.changed and b.image_path is None
    print("PASS no-change dedup")


def test_change_detected_with_crop():
    g = VisionGate()
    g.observe(make_png())
    r = g.observe(make_png(box=(100, 100, 80, 60, (255, 0, 0))))
    assert r.changed and r.image_path
    img = Image.open(r.image_path)
    # crop must be smaller than full page but contain the change
    assert img.size < (600, 400) and img.size[0] >= 80 and img.size[1] >= 60
    print("PASS change crop:", img.size)


def test_tiny_noise_ignored():
    g = VisionGate()
    g.observe(make_png())
    r = g.observe(make_png(box=(0, 0, 2, 2, (0, 0, 255))))  # 4 px noise
    assert not r.changed
    print("PASS noise gate")


def test_live_refs():
    from browser_agent.browser import BrowserController
    from browser_agent.dom_state import DomState
    import tempfile, os
    html = "<html><body><button onclick=\"this.innerText='clicked'\">Sign in</button><a href='#l'>Link A</a></body></html>"
    f = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False)
    f.write(html)
    f.close()
    ctrl = BrowserController(headless=True, use_cdp=False).start()
    try:
        ctrl.goto("file://" + f.name)
        s = DomState(ctrl.page).capture()
        assert '[0] button "Sign in"' in s and '[1] link "Link A"' in s
        ctrl.click(0)
        assert "clicked" in ctrl.page.inner_text("button")
        print("PASS live ref injection + click")
    finally:
        ctrl.stop()
        os.unlink(f.name)


if __name__ == "__main__":
    config.SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    test_no_change_skipped()
    test_change_detected_with_crop()
    test_tiny_noise_ignored()
    test_live_refs()
    print("ALL TESTS PASSED")
